# ft_package

```Bash
pip3 install setuptools wheel build
```

```Bash
python3 -m build
```

## install

```Bash
pip3 install ft_package
```
